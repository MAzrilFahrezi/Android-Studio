package com.if5b.kamus.databases;public class DatabaseContract {
}
